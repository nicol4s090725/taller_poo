# Ejemplos de POO en Java

Ejemplos sencillos de conceptos de programacion orientada a objetos.
Cada carpeta es independiente y tiene su propio `Main.java`.

| Carpeta | Concepto |
|---|---|
| 01-herencia | Herencia (Persona -> Empleado / Consultor) |
| 02-dependencia | Dependencia (Lector usa Libro) |
| 03-asociacion-muchos-a-muchos | Asociacion muchos a muchos (Estudiante - Curso) |
| 04-interfaz | Interfaz (Volador: Pajaro y Avion) |
| 05-clase-abstracta | Clase abstracta (Animal: Perro y Gato) |

## Como ejecutar

```bash
cd 02-dependencia
javac *.java
java Main
```
