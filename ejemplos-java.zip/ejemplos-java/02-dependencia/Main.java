public class Main {
    public static void main(String[] args) {
        Lector lector = new Lector("Ana");
        Libro libro = new Libro("Cien anios de soledad");
        lector.leer(libro);
    }
}
