public class Lector {
    private String nombre;

    public Lector(String nombre) {
        this.nombre = nombre;
    }

    // Dependencia: Lector USA a Libro solo dentro de este metodo.
    // Libro NO es un atributo de Lector.
    public void leer(Libro libro) {
        System.out.println(nombre + " esta leyendo \"" + libro.getTitulo() + "\"");
    }
}
