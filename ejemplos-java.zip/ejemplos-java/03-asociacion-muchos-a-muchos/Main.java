public class Main {
    public static void main(String[] args) {
        Estudiante ana = new Estudiante("Ana");
        Estudiante luis = new Estudiante("Luis");

        Curso java = new Curso("Programacion en Java");
        Curso calculo = new Curso("Calculo");

        ana.inscribirse(java);
        ana.inscribirse(calculo);
        luis.inscribirse(java);

        for (Curso curso : new Curso[]{java, calculo}) {
            System.out.println("Curso: " + curso.getNombre());
            for (Estudiante e : curso.getEstudiantes()) {
                System.out.println("  - " + e.getNombre());
            }
        }

        System.out.println("Cursos de Ana: " + ana.getCursos().size());
    }
}
