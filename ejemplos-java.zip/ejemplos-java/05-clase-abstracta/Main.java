public class Main {
    public static void main(String[] args) {
        // Animal a = new Animal("x");  // ERROR: no se puede instanciar una clase abstracta
        Animal perro = new Perro("Rocky");
        Animal gato = new Gato("Misu");

        perro.hacerSonido();
        perro.dormir();
        gato.hacerSonido();
        gato.dormir();
    }
}
