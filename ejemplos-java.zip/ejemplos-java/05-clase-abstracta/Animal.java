public abstract class Animal {
    protected String nombre;

    public Animal(String nombre) {
        this.nombre = nombre;
    }

    // Metodo concreto: todos los animales lo heredan tal cual
    public void dormir() {
        System.out.println(nombre + " esta durmiendo");
    }

    // Metodo abstracto: cada animal lo implementa a su manera
    public abstract void hacerSonido();
}
