public class Avion implements Volador {
    @Override
    public void volar() {
        System.out.println("El avion enciende los motores y despega");
    }
}
