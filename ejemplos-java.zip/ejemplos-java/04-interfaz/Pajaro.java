public class Pajaro implements Volador {
    @Override
    public void volar() {
        System.out.println("El pajaro bate las alas y vuela");
    }
}
