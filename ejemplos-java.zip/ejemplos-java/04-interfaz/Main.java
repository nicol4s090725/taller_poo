public class Main {
    public static void main(String[] args) {
        Volador[] voladores = { new Pajaro(), new Avion() };

        for (Volador v : voladores) {
            v.volar();
        }
    }
}
