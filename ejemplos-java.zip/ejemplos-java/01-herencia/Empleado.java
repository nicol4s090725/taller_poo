public class Empleado extends Persona {

 int numeroEmpleado;
 String cargo;
 Double salario;

 public Empleado(int id, String nombre, int edad, int telefono, String correo,
					  int numeroEmpleado, String cargo, Double salario) {
	 super(id, nombre, edad, telefono, correo);
	 this.numeroEmpleado = numeroEmpleado;
	 this.cargo = cargo;
	 this.salario = salario;
 }

 public int getNumeroEmpleado() {
    return numeroEmpleado;
 }

 public void setNumeroEmpleado(int numeroEmpleado) {
    this.numeroEmpleado = numeroEmpleado;
 }

 public String getCargo() {
    return cargo;
 }

 public void setCargo(String cargo) {
    this.cargo = cargo;
 }

 public Double getSalario() {
    return salario;
 }

 public void setSalario(Double salario) {
    this.salario = salario;
 }

   

}
