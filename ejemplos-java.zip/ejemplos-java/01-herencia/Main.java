public class Main {

 public static void main(String[] args) {
 
    Empleado e1 = new Empleado ( 67, "pepito", 23, 3233730, "pepito@example.com", 1001, "Gerente", 5000.0 );
  mostrarEmpleado(e1);
        
    Consultor c1 = new Consultor ( 6767, "juanito", 35, 318350, "juanito@example.com", "informatica", 100.0 );
    mostrarConsultor(c1);
 




 }

   private static void mostrarEmpleado(Empleado empleado) {
    System.out.println("Empleado: " + empleado.getNombre()
      + ", ID: " + empleado.getId()
      + ", Edad: " + empleado.getEdad()
      + ", Telefono: " + empleado.getTelefono()
      + ", Correo: " + empleado.getCorreo()
      + ", Numero de empleado: " + empleado.getNumeroEmpleado()
      + ", Cargo: " + empleado.getCargo()
      + ", Salario: " + empleado.getSalario());
   }

   private static void mostrarConsultor(Consultor consultor) {
    System.out.println("Consultor: " + consultor.getNombre()
      + ", ID: " + consultor.getId()
      + ", Edad: " + consultor.getEdad()
      + ", Telefono: " + consultor.getTelefono()
      + ", Correo: " + consultor.getCorreo()
      + ", Especialidad: " + consultor.getEspecialidad()
      + ", Tarifa: " + consultor.getTarifa());
  }
}
