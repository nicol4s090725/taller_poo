public class Consultor extends Persona {
  String especialidad;
  Double tarifa;
  public Consultor(int id, String nombre, int edad, int telefono, String correo, String especialidad, Double tarifa) {
    super(id, nombre, edad, telefono, correo);
    this.especialidad = especialidad;
    this.tarifa = tarifa;
  }
  public String getEspecialidad() {
    return especialidad;
  }
  public void setEspecialidad(String especialidad) {
    this.especialidad = especialidad;
  }
  public Double getTarifa() {
    return tarifa;
  }
  public void setTarifa(Double tarifa) {
    this.tarifa = tarifa;
  }
    

}
