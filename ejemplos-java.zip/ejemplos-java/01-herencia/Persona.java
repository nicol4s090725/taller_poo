public class Persona {
 int id;
 String nombre;
 int edad;
 int telefono;
 String correo;
 public Persona(int id, String nombre, int edad, int telefono, String correo) {
    this.id = id;
    this.nombre = nombre;
    this.edad = edad;
    this.telefono = telefono;
    this.correo = correo;
 }
 public int getId() {
    return id;
 }
 public void setId(int id) {
    this.id = id;
 }
 public String getNombre() {
    return nombre;
 }
 public void setNombre(String nombre) {
    this.nombre = nombre;
 }
 public int getEdad() {
    return edad;
 }
 public void setEdad(int edad) {
    this.edad = edad;
 }
 public int getTelefono() {
    return telefono;
 }
 public void setTelefono(int telefono) {
    this.telefono = telefono;
 }
 public String getCorreo() {
    return correo;
 }
 public void setCorreo(String correo) {
    this.correo = correo;
 }


}
